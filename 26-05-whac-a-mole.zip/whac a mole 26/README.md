Whac-A-Mole adalah game arcade klasik. Konsep permainan ini yaitu pemain harus memukul tikus-tikus kecil yang muncul dari lubang dengan palu secepat mungkin sebelum mereka kembali masuk ke lubang.

Pada game Whac-A-Mole, terdapat beberapa lubang yang masing-masing berisi tikus. Game ini dimainkan untuk mencapai score tertinggi. Semakin banyak dan tepat pukulan dilakukan, semakin tinggi skor akhirnya dan tempo tikus untuk keluar pada lubang akan semakin cepat. Namun, jika pemain melakukan ketidaktepatan memukul hingga beberapa kali, maka game dinyatakan berakhir dan ditampilkan score terakhir pemain.

Di dalam game terdapat fitur 'choose a mole' yang memberikan pemain opsi untuk memilih dari tiga jenis mol yang berbeda, yang akan muncul selama permainan berlangsung. Sehingga dapat memberikan variasi pada pengalaman bermain game

Anggota kelompok :
1. Muhammad Fabil (121140189)
2. Made Redy Wijaya (121140157)
3. Marchel Ferry (121140195)
4. Ken Annissa (121140188)
5. Salma Zurida (121140064)
6. Elinca Savina (121140073)